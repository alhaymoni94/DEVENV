# TUI Applications and Extensions

This document lists all Terminal User Interface (TUI) applications and related extensions installed on the system from various package managers.

## Package Manager: pipx

### 1. Euporie
- **Description**: Euporie is a text-based user interface (TUI) application for Jupyter notebooks. It provides a terminal-based environment for interactive computing and data analysis.
- **Commands**:
  - `euporie`: Main application
  - `euporie-console`: Console interface
  - `euporie-hub`: Hub for managing notebooks
  - `euporie-notebook`: Notebook interface
  - `euporie-preview`: Preview tool
- **Version**: 2.10.3

### 2. SQLit
- **Description**: SQLit is a TUI for databases, allowing users to interact with various database systems through a terminal interface. It supports multiple database types including SQLite, PostgreSQL, MySQL, and more.
- **Commands**:
  - `sqlit`: Main application
- **Version**: 1.3.1

## Package Manager: apt

### 1. GNOME Terminal
- **Description**: GNOME Terminal is a terminal emulation application for the GNOME desktop environment. It provides a graphical interface for command-line access.
- **Commands**:
  - `gnome-terminal`: Main application
- **Version**: 3.52.0-1ubuntu2

### 2. Warp Terminal
- **Description**: Warp Terminal is a modern, Rust-based terminal emulator with built-in features like command palette, AI assistance, and collaborative editing.
- **Commands**:
  - `warp-terminal`: Main application
- **Version**: 0.2026.04.15.08.45.stable.02

## Package Manager: brew

### 1. btop
- **Description**: btop is a modern and colorful resource monitor for the terminal. It displays system resources like CPU, memory, disk, network, and processes in a visually appealing way.
- **Commands**:
  - `btop`: Main application
- **Version**: Latest (installed via brew)

### 2. lazygit
- **Description**: lazygit is a simple terminal UI for git commands. It provides an interactive interface for managing git repositories, including status, branch, log, and stash operations.
- **Commands**:
  - `lazygit`: Main application
- **Version**: Latest (installed via brew)

### 3. lazydocker
- **Description**: lazydocker is a terminal UI for managing Docker containers and services. It provides an interactive interface for viewing and managing Docker resources.
- **Commands**:
  - `lazydocker`: Main application
- **Version**: Latest (installed via brew)

### 4. glow
- **Description**: glow is a terminal-based markdown reader. It renders markdown files with styling and supports features like tables, code blocks, and syntax highlighting.
- **Commands**:
  - `glow`: Main application
- **Version**: Latest (installed via brew)

### 5. harlequin
- **Description**: Harlequin is a SQL IDE for the terminal. It provides an interactive interface for writing and executing SQL queries against various database systems.
- **Commands**:
  - `harlequin`: Main application
- **Version**: Latest (installed via brew)

## Package Manager: npm/npx

No TUI-specific applications were found installed via npm or npx.

## Package Manager: pip

No TUI-specific applications were found installed via pip.

---

*Last updated: 2024-10-06*